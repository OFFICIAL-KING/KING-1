echo "WAIT..."
echo "15 SEC ONLY"
echo "YOU WILL AUTOMATICLY"
echo "GO BACK IN PUBG"
echo "DONT FORGET TO USE\nMEMORY ANTIBAN IN LOBBY"
mv /data/data/com.tencent.ig/lib/libtprt.so /storage/emulated/0/Download/KING-1/REAL_KING-1
mv /data/data/com.tencent.ig/lib/libUE4.so /storage/emulated/0/Download/KING-1/REAL_KING-1
mv /data/data/com.tencent.ig/lib/libzlib.so /storage/emulated/0/Download/KING-1/REAL_KING-1
sleep 10
mv /storage/emulated/0/Download/KING-1/FAKE_KING-1/libzlib.so /data/data/com.tencent.ig/lib/libzlib.so
mv /storage/emulated/0/Download/KING-1/FAKE_KING-1/libUE4.so /data/data/com.tencent.ig/lib/libUE4.so
mv /storage/emulated/0/Download/KING-1/FAKE_KING-1/libtprt.so /data/data/com.tencent.ig/lib/libtprt.so
sleep 10
am start -n com.tencent.ig/com.epicgames.ue4.SplashActivity
echo "DONE"
echo "CREATOR :- IAMX_YT"
echo "TELEGRAM CHANNEL:--- @king_gaming_hub "
